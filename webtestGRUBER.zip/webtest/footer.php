<footer class="footer bg-transparent text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-2">
    © 2022 Copyright:
    <a class="text-dark" href="index.php">Webtech Test</a>, <a class="text-dark" href="imprint.php">Imprint</a>
  </div>
  <!-- Copyright -->
</footer>