<?php
session_start();


    $rightUser = "thisUser";
    $rightPW = "password123";
    if(!isset($_SESSION["loggedIn"])){ //Login Daten in Session speichern, dann bleibt man eingeloggt
      $_SESSION["loggedIn"] = false;
    }
    if(!$_SESSION["loggedIn"]){
      if($_POST["usrnm"]==$rightUser && $_POST["pw"] == $rightPW){
        $_SESSION["username"]=$_POST["usrnm"];
        $_SESSION["password"]=$_POST["pw"];
        $_SESSION["loggedIn"] = true; //Man kann auf Reservierung zugreifen, ohne sich nochmal einzuloggen
      }
      else if(!isset($_POST["pw"])){
        header("Location: Login.php?nopw=true");
      }
      else {
        header("Location: Login.php?Loginerror=true&username=".$_POST["usrnm"]); //Falsche Daten eingegeben: error wird ausgebenen bei Login
      }
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="StyleNav.css">
    <title>Log-In Erfolgt</title>
</head>
<body>
  <style>
   .box{
      border-radius: 4%;
      display: block;
      background-color: lightblue;
      padding: 1%;
    }
  </style>
<?php include 'Navbar.php'?>
       <div class="container">
          <div class="row"> 
            <div class= "col" style="margin-top:1%;">    
            Willkommen zurück! Sie sind eingeloggt als <?php echo  $_SESSION["username"]; 
            ?> .
            </div>
            <div class="col" style="margin-top:1%;">
              <input type="submit" value="Meine Daten ändern" onclick="window.open('Registrierung.php');">
            </div>
          </div>
          <div class="row">
            <div class="col box" style="margin-top: 1%;">
              <form action="Berechnung.php" action="get">
                <label for="Zimmer">Reservieren sie ein Zimmer:</label> <br/>
                 Doppelzimmer Standard <input type="number" name="anzahlStd" style="width: 2em"> 140 € p. P.<br>
                 Deluxe Doppelzimmer <input type="number" name="anzahlDel" style="width: 2em"> 200 € p. P.<br>
                 Einzelzimmer <input type="number" name="anzahlEinz" style="width: 2em"> 120 € p. P.<br>
                 Familienzimmer <input type="number" name="anzahlFam" style="width: 2em"> 180 € p. P.<br>
                <input type="submit" name="Buchen" value="Preis berechnen">
              </form>
            </div>
          </div>
        </div>
            
       
    
    
    
</body>
</html>